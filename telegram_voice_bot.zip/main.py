import telebot
from gtts import gTTS
import os
import json
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from flask import Flask
from threading import Thread

BOT_TOKEN = 'YOUR_BOT_TOKEN_HERE'
bot = telebot.TeleBot(BOT_TOKEN)

LANG_FILE = "user_languages.json"

def load_languages():
    if os.path.exists(LANG_FILE):
        with open(LANG_FILE, 'r') as f:
            return json.load(f)
    return {}

def save_languages(data):
    with open(LANG_FILE, 'w') as f:
        json.dump(data, f)

user_languages = load_languages()

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message,
                 "👋 Welcome to the Text-to-Speech Bot!\n\n"
                 "📝 Send me any text and I will convert it to voice.\n"
                 "🌐 Use /lang ar or /lang en to set your preferred language.")

@bot.message_handler(commands=['lang'])
def set_language(message):
    try:
        lang = message.text.split()[1].lower()
        if lang in ['en', 'ar']:
            user_languages[str(message.from_user.id)] = lang
            save_languages(user_languages)
            msg = "✅ Language set to English." if lang == 'en' else "✅ تم تعيين اللغة إلى العربية."
            bot.reply_to(message, msg)
        else:
            bot.reply_to(message, "❌ Invalid language. Use `/lang ar` or `/lang en`.")
    except IndexError:
        bot.reply_to(message, "ℹ️ Please specify a language. Example: /lang ar")

@bot.message_handler(func=lambda m: True)
def handle_text(message):
    text = message.text.strip()
    user_id = str(message.from_user.id)
    lang = user_languages.get(user_id, 'en')

    if not text:
        bot.reply_to(message, "⚠️ Please send some text.")
        return

    try:
        tts = gTTS(text=text, lang=lang)
        filename_mp3 = f"tts_{user_id}.mp3"
        filename_ogg = f"tts_{user_id}.ogg"

        tts.save(filename_mp3)
        os.system(f"ffmpeg -i {filename_mp3} -ar 24000 -ac 1 -c:a libopus {filename_ogg} -y")

        buttons = InlineKeyboardMarkup()
        buttons.row(
            InlineKeyboardButton("🎧 Play Voice", callback_data=f"voice:{user_id}"),
            InlineKeyboardButton("🎵 Download MP3", callback_data=f"audio:{user_id}")
        )

        bot.send_message(message.chat.id, "✅ Voice generated! Choose an option below:", reply_markup=buttons)

    except Exception as e:
        bot.reply_to(message, f"❌ Error generating voice: {e}")

@bot.callback_query_handler(func=lambda call: True)
def handle_buttons(call):
    data = call.data
    user_id = call.from_user.id
    mp3_file = f"tts_{user_id}.mp3"
    ogg_file = f"tts_{user_id}.ogg"

    if data.startswith("voice:"):
        if os.path.exists(ogg_file):
            with open(ogg_file, "rb") as audio:
                bot.send_voice(call.message.chat.id, audio, caption="🎧 Here's your voice message.")
        else:
            bot.answer_callback_query(call.id, "⚠️ Voice file not found.")
    elif data.startswith("audio:"):
        if os.path.exists(mp3_file):
            with open(mp3_file, "rb") as audio:
                bot.send_audio(call.message.chat.id, audio, caption="🎵 Here's your MP3 file.")
        else:
            bot.answer_callback_query(call.id, "⚠️ MP3 file not found.")

# Keep alive with Flask
app = Flask('')

@app.route('/')
def home():
    return "I'm alive!"

def run():
    app.run(host='0.0.0.0', port=8080)

Thread(target=run).start()

print("✅ Bot is running...")
bot.infinity_polling()
